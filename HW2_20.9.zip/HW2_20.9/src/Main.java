import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {

        //Первое задание
        Random rnd = new Random();
        int[] array = ThreadLocalRandom.current().ints(8, 1, 51).toArray(); //1
        String asString = Arrays.toString(array); //2
        System.out.println(asString);

        Arrays.sort(array); //5
        String asString3 = Arrays.toString(array); //6
        System.out.println(asString3);

        for (int i = 0; i < array.length; i += 2) { //3
            array[i] = 0;
        }
        String asString2 = Arrays.toString(array); //4
        System.out.println(asString2);

// Здравствуйте, Юрий. Я поменял местами пункты 3 и 5 только для вида.
// Чтобы был отсортирован массив не с четырьмя нулями, а с 8ю различными числами.
// В противном случае в пятойт пункте метод "Arrays.sort" получил бы массив уже с замененными значениями у элементов с нечетным индексом.
// Надеюсь это не будет считаться за ошибку или дедочет.


        // Второе задание

        String[] bundesLaender = {"Niedersachsen", "Baden-Wuertenberg", "Nordrhein-Westfalen", "Bayern", "Hessen"};
        String deutch = Arrays.deepToString(bundesLaender);
        System.out.println(deutch);
        String max = bundesLaender[0];
        String min = bundesLaender[0];

        for (int i = 1; i < bundesLaender.length; i++) {
            if (max.length() < bundesLaender[i].length()) {
                max = bundesLaender[i];
            }
            if (min.length() > bundesLaender[i].length()) {
                min = bundesLaender[i];
            }
        }
        System.out.println(max);
        System.out.println(min);
    }
}

//No1.
//1. Создайте массив из 8 случайных целых чисел из интервала [1;50]
//2. Выведите массив на консоль в строку.
//3. Замените каждый элемент с нечетным индексом на ноль.
//4. Снова выведете массив на консоль в отдельной строке.
//5. Отсортируйте массив по возрастанию.
//6. Снова выведете массив на консоль в отдельной строке.

//No2.
//1. Создайте массив из 5 строк. Используя метод length() строк,
// найдите строку с наибольшей длиной и строк с наименьшей длиной.
//2. Выведите массив и полученный строки в консоль