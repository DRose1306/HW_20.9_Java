public class Main {
    public static void main(String[] args) {
        int N = 10;
        int[] array = {1, 2, 3, 4, 5, 6, 8, 9, 10}; //
        int missingElement = findMissingElement(array, N);
        System.out.println("Недостающий элемент: " + missingElement);
    }

    public static int findMissingElement(int[] array, int N) {
        int awaitedSum = (N * (N + 1)) / 2;
        int actualSum = 0;
        for (int num : array) {
            actualSum += num;
        }
        return awaitedSum - actualSum;

    }
}
//Дан массив размера N-1 ,
// содержащий только различные целые числа в диапазоне от 1 до N .
// Найдите недостающий элемент.
//Пример 1: Вход:
//N=5
//А[] = {1,2,3,5} Выход: 4
//Пример 2:
//Вход:
//N = 10
//А[] = {6,1,2,8,3,4,7,10,5} Выход: 9