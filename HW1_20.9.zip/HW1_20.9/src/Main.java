import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
        первое задание
         */
        System.out.println("произведение двух чисел равно " + getMultiply(1, 2));
        System.out.println();
        System.out.println("произведение трех чисел равно " + getMultiply(1, 2, 3));
        System.out.println();
        System.out.println("произведение четырех чисел равно " + getMultiply(1, 2, 3, 4));
        System.out.println();
        /*
        второе задание
         */
        Scanner scn = new Scanner(System.in);
        int number;
        do {
            System.out.println("Введите желаемое число");
            number = scn.nextInt();
        } while (number < 0);

        int factorial = fact(number);
        System.out.println("Факториал числа " + number + " = " + factorial);
    }

    private static int getMultiply(int num1, int num2) {
        return num1 * num2;
    }

    private static int getMultiply(int num1, int num2, int num3) {
        return getMultiply(getMultiply(num1, num2), num3);
    }

    private static int getMultiply(int num1, int num2, int num3, int num4) {
        return getMultiply(getMultiply(num1, num2, num3), num4);
    }

    private static int fact(int n) {
        return (n==1)? 1 :  n * fact(n - 1);
    }
}
//Задание 1.
//Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
// В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
// В методе умножения 4-х чисел – вызов метода для 3-х чисел.

//Задание 2.
//Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.